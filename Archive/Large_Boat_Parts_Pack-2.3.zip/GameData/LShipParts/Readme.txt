Changelog:
2.3
Added dedicated carrier parts

======================================================
*If you like big boats in KSP this mod is for you.

*This mod is still in development

*Ive made the textures simple to edit. So have at em if you dont like the ones ive made.

*Since these parts are very large and will fill the SPH or VAB Quickly. I recommend getting:
	-WASD editor camera or some limit extending mod
	-VesselMover to move your new creations out to sea (if its even a boat of course)



































If you have any comments, questions, etc. Email me at: christitus8@gmail.com
