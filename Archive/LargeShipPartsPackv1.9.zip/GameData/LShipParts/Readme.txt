

======================================================
*If you like big boats in KSP this mod is for you.

*The engines were added in recently. I van change the fuel consumption yet so i included a fuel generator in them. 
Its not realistic at all but it kind of balances things. It only runs on liquid fuel and only generates liquid fuel.

*This mod is still in development

*There are no propulsion systems yet but I plan on adding some later on
 Right now more decorative/structural parts is what im focusing on.

*Ive made the textures simple to edit. So have at em if you dont like the ones ive made.

*Since these parts are very large and will fill the SPH or VAB Quickly. I recommend getting:
	-WASD editor camera or some limit extending mod
	-VesselMover to move your new creations out to sea (if its even a boat of course)



































If you have any comments, questions, etc. Email me at: christitus8@gmail.com
