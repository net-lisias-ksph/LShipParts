Modern Half

======================================================
*If you like big boats in KSP this mod is for you.

*This mod is still in development

*Ive made the textures simple to edit. So have at em if you dont like the ones ive made.

*Since these parts are very large and will fill the SPH or VAB Quickly. I recommend getting:
	-WASD editor camera or some limit extending mod
	-VesselMover to move your new creations out to sea (if its even a boat of course)
	
LBP 3.6.1
Prior to the upcoming release of LBP 3.6.1 a lot of effort was spent trying to combine the abilities of the hangar mod to store other vessels with the hangar and storage area parts of LBP, this was only partly succesful and we could not go forward with the hangar additions at this time, should the hangar mod become more versatile regarding other parts not from the hangar mod we'll revisit the feature. While a feature like this is very desirable and opens up a world of options, the hangar mod as it stands has too much other stuff (5 plugins just to store an aircraft in a hangar is too much for me)going on for me to make any feature dependant on it


































If you have any comments, questions, etc. Email me at: christitus8@gmail.com
